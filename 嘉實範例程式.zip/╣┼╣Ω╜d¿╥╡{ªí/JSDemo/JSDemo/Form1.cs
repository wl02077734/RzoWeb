﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DJTRADEOBJLibPSCAP;
using JDPSCAPQuoteOBJLib;
using System.IO;
using System.Threading;


namespace JSDemo
{
    public partial class Form1 : Form
    {
        delegate void DeleGateOrder(int nEventID, string sResponseData);
        DeleGateOrder DeleGateOrderResponse;


        delegate void DeleGateQuote(string SymbolID, object val);
        DeleGateQuote DeleGateQuoteResponse;

        StreamWriter txtflog;

        public Form1()
        {
            InitializeComponent();
            JSOrderAPI = new TradeAppClass();

        }

        //DJTRADEOBJLibPSCAP.TradeAppClass m_tradeApp;
        String strTradeDAS = "APItest.pscnet.com.tw/tradedas";
        //String strTradeDAS = @"APITrade.pscnet.com.tw/tradedas";



        // JSAPI
        // ==================================================================================
        public static TradeAppClass JSOrderAPI;
        public static ApplicationJDPSCAPQuote JSQuoteAPI = new ApplicationJDPSCAPQuote();

        private void Form1_Load(object sender, EventArgs e)
        {
            txtAcc.Text = Properties.Settings.Default.txtAcc;
            txtPwd.Text = Properties.Settings.Default.txtPwd;
            txtflog = new StreamWriter(@".\log\log_" + DateTime.Now.ToString("yyyyMMdd") + ".txt", true);


            DeleGateOrderResponse = new DeleGateOrder(m_tradeApp_OnDataResponse);
            //bind 下單主動回報的事件
            JSOrderAPI.OnDataResponse += new _ITradeAppEvents_OnDataResponseEventHandler(CallOrderDelegate);


            JSQuoteAPI.Init();
            DeleGateQuoteResponse = new DeleGateQuote(JSQuoteAPIOnSymbolTickfun);
            //bind 報價行情的事件
            JSQuoteAPI.OnSymbolTick += new IJDPSCAPQuoteNotify_OnSymbolTickEventHandler(CallQuoteDelegate);

            

        }




        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            JSOrderAPI.Fini2(Properties.Settings.Default.txtAcc);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBox12.Text = "";
                //op11.Text = "";
                int m_nTradeDate = Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd"));// 交易日期(西元年月日)
                int nTT = 0; // 0: 普通/ 1: 盤後零股/ 2: 盤後/ 5:興櫃/ 7:盤中零股
                int nOT = 0; // 0: 現股/ 1:融資/ 2: 融券/ 16: 現沖
                int nBS = 1; // 1: 買進/ 2: 賣出/ 3:超買/ 4:超賣 (3/4 for 興櫃)
                string szStockID = txtStock.Text; // 股號
                int nQty = Convert.ToInt32(txtOrderQty.Text); // 普通&盤後(張數) / 零股(股數) / 興櫃(股數)
                int nPT = 0; // 0: 限價/ 1: 漲停/ 2: 跌停/ 3: 平盤/ 4:  市價
                string szPrice = txtPrice.Text; // 價格
                string szBroker = "5850"; // 推薦券商for 興櫃
                int nPayType = 0; // 0:餘額交割/ 1:逐筆交割 (for 興櫃)
                int nCond = 0; // 0:  ROD/ 1:FOK/ 2:  IOC

                string strResult = JSOrderAPI.Stock_NewOrder(cbAcc.SelectedItem.ToString(), m_nTradeDate, nTT, nOT, nBS, szStockID, nQty, nPT, szPrice, szBroker, nPayType, nCond);

                richTextBox12.Text = strResult;
            } catch (Exception ex)
            {
                MessageBox.Show("請先登入-error：" + ex.Message);
            }
        }


        private void m_tradeApp_OnDataResponse(int nEventID, string sResponseData)
        {
            if (nEventID == 100)
            {
                richTextBox6.Text += sResponseData + "\n\n";
                string Data = sResponseData.Replace(">", "").Replace("<", "");
                string OrderStatus = GetDataData(Data, "F2=");
                switch (OrderStatus)
                {
                    case "11"://委託成功
                    case "12"://委託失敗
                    case "22"://刪單失敗
                        //op11.Text = sResponseData;
                        break;


                    case "40"://成交
                        //op40.Text = sResponseData;
                        break;
                }

                txtflog.WriteLine(DateTime.Now.ToString("HH:mm:ss.fff") + "_" + sResponseData);
                txtflog.Flush();
            }
        }



        private void CallOrderDelegate(int nEventID, string sResponseData)
        {
            if (nEventID == 100)
            {
                this.Invoke(DeleGateOrderResponse, new object[] { nEventID, sResponseData });
            }

        }

        private void CallQuoteDelegate(string SymbolID, object val)
        {
            this.Invoke(DeleGateQuoteResponse, new object[] { SymbolID, val });
        }


        public static string GetDataData(string SourceS, string DataName)
        {
            string ReturnData = "";
            try
            {
                int PosS = SourceS.IndexOf(DataName);
                int PosE = -1;
                if (PosS > -1)
                {
                    PosS = PosS + DataName.Length;
                    PosE = SourceS.IndexOf("|", PosS);
                    if (PosE == -1) PosE = SourceS.Length;
                    ReturnData = SourceS.Substring(PosS, PosE - PosS);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("GetDataData-error：" + ex.Message);
            }
            return ReturnData;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

            int nErrCode;
            String sErrMsg;
            int nRet = JSOrderAPI.Init2(strTradeDAS, txtAcc.Text, txtPwd.Text, out nErrCode, out sErrMsg);
            richTextBox15.Text = Convert.ToString(nRet+ ";ErrCode=" + nErrCode+ ";ErrMsg=" + sErrMsg);
            if (nRet == 1)
            {

                JSOrderAPI.SetExecOrderType(0); // 0: Auto, 1: HTTP, 2: Socket
                //int nCmdType = 1; // 1: Order, 2: QueryTrade, 3: QueryData
                //int nEchoType = 0; // 0: Sync, 1: ASync
                JSOrderAPI.SetEchoType(1, 0); //nCmdType, nEchoType
                JSOrderAPI.SetEchoType(2, 0); //nCmdType, nEchoType
                JSOrderAPI.SetEchoType(3, 0); //nCmdType, nEchoType

                //下拉式選單加入證券帳號
                int accCount = JSOrderAPI.GetAccountCount();
                for (var i = 0; i < accCount; i++)
                {
                    string acc = JSOrderAPI.GetAccount(i);
                    string[] strArray = acc.Split(new string[] { "<ID=", "|Name" }, StringSplitOptions.RemoveEmptyEntries);
                    cbAcc.Items.Add(strArray[0]);

                    
                }
                cbAcc.SelectedIndex = 0;

                Properties.Settings.Default.txtAcc = txtAcc.Text;
                Properties.Settings.Default.txtPwd = txtPwd.Text;
                Properties.Settings.Default.Save();
            }
        }

       

        private void cancelOrder_Click(object sender, EventArgs e)
        {
            string rv = "";
            try
            {
                rv = JSOrderAPI.Stock_CancelOrder
                    (
                        cbAcc.SelectedItem.ToString(),           // AcNo
                        Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")),// 交易日期(西元年月日)
                        0,      // TradeType: 0:普通, 1:零股, 2:盤後, 5:興櫃
                        0,      // OrderType: 0:現股, 1:融資, 2:融券
                        textBox2.Text,            // 委託單編號
                        "",        // 委託書號
                        textBox1.Text,        // StockNo
                        1,             // 1:買進, 2:賣出 
                        0,              // Qty
                        0,              // tmpQcurrent,
                        0,              // Qmatch,
                        0,            // PreOrder,
                        0               // 0:ROD, 1:FOK, 2:IOC
                    );
                richTextBox14.Text = rv;
            } catch (Exception ex)
            {
                MessageBox.Show(rv + ex.Message);
            }
        }


        private void tabPage3_Click(object sender, EventArgs e)
        {

        }


        private void btnModifyOrder_Click(object sender, EventArgs e)
        {
            string rv = "";
            try
            {
                rv = JSOrderAPI.Stock_ModifyOrder
                    (
                        cbAcc.SelectedItem.ToString(),           // AcNo
                        2, // 0:改量  2:改價
                        Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")),// 交易日期(西元年月日)
                        0,      // 0: 普通/ 1: 盤後零股/ 2: 盤後/ 5:興櫃/ 7:盤中零股
                        0,      // OrderType: 0:現股, 1:融資, 2:融券
                        textBox8.Text,            // 委託單編號
                        "",        // 委託書號
                        textBox6.Text,        // StockNo
                        1,             // 1:買進, 2:賣出 
                        0,              // 取消數量/取消後股數
                        0,              // 有效張數
                        0,              // 成交張數
                        0,             //  0:盤中單/1: 預約單

                        textBox7.Text,            // new price ( for 改價,  改量給空的 )
                        0,            // 0:  限價/ 1:  漲停/ 2: 跌停/ 3:  平盤
                        0               // 0:ROD, 1:FOK, 2:IOC
                    );
                richTextBox13.Text = rv;
            }
            catch (Exception ex)
            {
                MessageBox.Show(rv + ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string strResult = JSOrderAPI.Stock_QueryOrder(cbAcc.SelectedItem.ToString(), 1);
                richTextBox8.Text = strResult;
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAddSymbol_Click(object sender, EventArgs e)
        {
            JSQuoteAPI.AddSymbols(textBox3.Text + ".TW");
            JSQuoteAPI.AddSymbolTick(textBox3.Text + ".TW");
        }

       
        
        private void JSQuoteAPIOnSymbolTickfun(string SymbolID, object val)
        {
            object[] tmpData = (object[])val;
            richTextBox10.Text += string.Join(",", tmpData) + "\n\n"; ;
        }

        private void btnModifyQty_Click(object sender, EventArgs e)
        {
            string rv = "";
            try
            {
                rv = JSOrderAPI.Stock_ModifyOrder
                    (
                        cbAcc.SelectedItem.ToString(),           // AcNo
                        0, // 0:改量  2:改價
                        Convert.ToInt32(DateTime.Now.ToString("yyyyMMdd")),// 交易日期(西元年月日)
                        0,      // 0: 普通/ 1: 盤後零股/ 2: 盤後/ 5:興櫃/ 7:盤中零股
                        0,      // OrderType: 0:現股, 1:融資, 2:融券
                        textBox8.Text,            // 委託單編號
                        "",        // 委託書號
                        textBox6.Text,        // StockNo
                        1,             // 1:買進, 2:賣出 
                        Convert.ToInt32(textBox4.Text),              // 取消數量/取消後股數
                        0,              // 有效張數
                        0,              // 成交張數
                        0,             //  0:盤中單/1: 預約單

                        "",            // new price ( for 改價,  改量給空的 )
                        0,            // 0:  限價/ 1:  漲停/ 2: 跌停/ 3:  平盤
                        0               // 0:ROD, 1:FOK, 2:IOC
                    ) ;
                richTextBox13.Text = rv;
            }
            catch (Exception ex)
            {
                MessageBox.Show(rv + ex.Message);
            }
        }
    }
}
